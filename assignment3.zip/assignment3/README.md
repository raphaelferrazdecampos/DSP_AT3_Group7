# To be filled by students

# Description
The structure of the folder is composed by:

/app: folder with the main code for generating the streamlit app which is dependent of files in the src folder
/src: folder including the individual python modules to create the 4 different sections described in the report
'__init__.py': file necessary for streamlit_app.py to recognize the modules inside the src subfolder

Dockerfile: file to build the Docker container 
docker-compos.yml: file to simplify the creation of the Docker container and its images


# Authors
Raphael Ferraz de Campos

# Structure
/assigment3
    /app
    __init__.py
    streamlit_app.py
        /src
        data.py
        text.py
        numeric.py
        datetime.py
Dockerfile
README
docker-compose.yml
requirements.txt

# Instructions

to run the web application the rout folder, assigment3 in this case, needs to be saved in the local drive.
Once the folder is saved, ope terminal and run docker-compose.yml file running the command docker-compose up -d
the yml will send the command directly to the dockerfile and install all necessary packages under requirements.txt and push it into Docker.
Once the process is finalised, open a web browser of your preference and search for localhost:8501


